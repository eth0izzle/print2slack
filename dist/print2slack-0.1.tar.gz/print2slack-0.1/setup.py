from setuptools import setup

setup(
    name='print2slack',
    version='0.1',
    description='print() to slack!',
    license='MIT',
    packages=['print2slack'],
    author='Paul Price',
    author_email='paul@ifc0nfig.com',
    keywords=['slack'],
    url='https://github.com/eth0izzle/print2slack'
)